# Remaining verification targets after Lemmas 4.14 and 4.2

**The current proof inventory is 47 of 69, with 22 assertions remaining.**
[`Overfull.ordinary_core_factorization`](../Overfull/OrdinaryFactorization/Full.lean)
proves the full Lemma 4.2, and `ordinary_core_one_factorization` returns
the explicit perfect-matching partition of all original edge copies.
The full module and its dependencies passed a strict targeted build with
3,341 jobs and no warnings. Independent semantic review also passed.
The repository-wide strict build passed with 3,648 jobs. The repository-wide
status, full axiom inventory, and exact source/input hashes are recorded in
[verification/results.json](../verification/results.json).
The main theorem remains unverified.

The [full ordinary-core proof](ordinary-factorization-full.md),
[source mapping](ordinary-factorization-full-source.json),
[semantic review](ordinary-factorization-full-semantic-review.md), and
[declaration map](../verification/ordinary-factorization-full-declarations.json)
record the new completion. The separate
[boundary-extension proof](boundary-extension.md) already established
Lemma 4.14 with pointwise agreement on every prescribed boundary label.

## What this checkpoint closes

The general ordinary-core preprocessing already constructed a first
matching family and an actual robust bipartite residual with a colored
complement. It did not itself color the whole residual. The bounded-exterior
continuation now constructs the extra structure needed to finish it under
all the original hypotheses of Lemma 4.2.

The exterior part of each complement color is a matching saturating the
exterior, with an even core footprint of bounded size. A paired random cut
balances many such footprints while satisfying the degree and robust-cut
requirements. The proof allows overlap and arbitrary correlation between
footprints. A finite pigeonhole argument chooses one balanced exterior
split and a linear set of labels whose actual exterior copies cross that
augmented cut. Those labels are avoided by the first matching family and
transported exactly through the residual palette.

The selected residual complement is then colored by palette compression
and a proved finite extension, balanced, and completed through robust
bipartite packing. The whole remaining graph is proved bipartite and
regular, so König colors it. Reconstruction gives the original-copy
factorization. This construction includes an empty exterior and fixes
all constants before the host.

This proof does not assume Theorem 6.1, a spanning bi-setup, or a robust
absorber. It uses freedom to choose the cut of an ordinary robust core;
the general factorization for a prescribed bipartite core and its shores
remains open. The earlier one-apex and two-apex proofs of Lemma 4.14
remain available independently of this new bounded-exterior construction.

## The next full factorization obligations

| Numbered target | Checked inputs | Substantive remaining work |
| --- | --- | --- |
| Lemma 4.4 and Corollaries 4.5–4.6 | Full ordinary-core Lemma 4.2, matching distributions, pattern and coloring components, and the separate one-apex factorization | Construct the actual matching deletions, reductions, and complementary colorings required by the fixed-pattern statement; retain its one-or-two-core scope and original heavy-pattern hypothesis. Derive the smaller-exception corollaries only after that full construction. |
| Proposition 4.16: terminal factorization | Frequent-pattern reduction, full boundary extension (4.14), and full four-odd joining decomposition (4.15) | Complete every parity branch and reassemble the full host factorization. The all-even and mixed-parity branches still require the compatible-circuit and general bounded-input factorization work. |
| Proposition 4.17 and the structural coloring cases | Safe matching deletions, exceptional absorption, frequent patterns, full ordinary-core factorization, and boundary extension | The remaining terminal factorization and the source-level compositions for the required critical cases. |
| Theorem 6.1, Proposition 6.2, and Theorem 6.3 | Uniform localization, coupled parameters, actual reserved-remainder packing, and exact regular orientation | Construct the complete compatible spanning setup, special path systems, actual robust absorber/reservation, and final full-host reconstruction from the original hypotheses. |

A concrete next assessment is the full fixed-pattern Lemma 4.4. Its source
statement allows one or two cores and requires a boundary pattern of
weight at least `c*k`, with at most `4-q` internal exceptional pairs. The
new Lemma 4.2 supplies the final ordinary-core factorization once the
actual component or contraction and its complementary coloring have been
constructed. The preceding pattern rounding, safe deletions, exceptional
reduction, and palette alignment still need a complete source-level proof.

Corollary 4.6 is therefore not an automatic consequence of the new result.
Its original hypotheses give no-overfullness and a small exceptional set,
rather than a coloring of the complement of every core. The one-core case
still needs that coloring constructed after the required reduction, while
the two-core case also needs the joining-edge and palette assembly.
Lemma 4.4's full conclusion or a replacement proved under these original
hypotheses must supply those inputs before either corollary is counted.

### Proposition 4.16 is not an immediate composition

The terminal proposition quantifies over the whole graph produced by
Lemma 4.13. Its even order permits zero, two, or four odd parts. The source
handles these configurations differently:

- **All parts even:** compatible quotient circuits must lift to actual
  joining-edge matchings, be assigned to bounded-footprint colors, and be
  completed. The source then uses Corollary 4.6 on the remaining even
  regular components.
- **Exactly two odd parts:** virtual-edge circuit constructions must give
  actual paths and surplus circuits with the needed endpoint constraints.
  After preliminary completions, the contracted residual can have one or
  two cores and two other vertices; the source again invokes the general
  bounded-input factorization. A two-apex graph with the particular supply
  used in the new cleanup has not been derived for every such residual.
- **Four odd parts:** Lemmas 4.14 and 4.15 now provide the full boundary
  extension and joining decomposition required by this branch. The
  remaining source-level selection, deletion, boundary-color assignment,
  and global reassembly must still be assembled on actual original copies.

The existence of the full inputs for the four-odd branch does not prove
all parity branches of Proposition 4.16. It must retain its incomplete
status until its full conclusion is obtained under its original scope.

## General Section 6 route: preserve the checked checkpoint

The [reserved-remainder continuation](residual-factorization.md) added
**99 public theorem proofs in eight modules** and retained the historical
**45/69** count. It constructs the coupled absorber integers, exact palette
identities, source palette budgets, and divisibilities. It also proves
uniform packing through an actual simple regular bipartite remainder and
constructs its balanced orientation.

Its public `exists_uniform_reserved_remainder` starts with the original
regular host and an explicit reserved-copy set. It derives the actual
retained core, robustness, and degree-error bounds and completes the
supplied balanced remaining exterior coloring. The reserved set and that
colored exterior remain explicit stage inputs. The theorem does not
assert their existence from the full original factorization hypotheses.

The [uniform-localization results](uniform-localization.md) already supply:

- Actual simultaneous palettes, positive even rounded palette sizes, and
  uniform error and order choices.
- Actual equal fine positions, exact coarse unions, and simultaneous
  compatible vertex blocks from divisible populations of sufficient size.
- Derived floor-cap intervals, correction-row small-error bounds, and
  actual sampling budgets.
- A preferred-row-only construction for the no-correction branch, including
  actual zero-correction selection without a correction-score premise.
- Actual normalized boundary weights, a light existing cluster, and
  original-copy loss bounds for bounded-weight boundaries.
- Exact adaptive pool loss, fine-to-coarse reserve accounting, preferred
  supplies, strict coloring reserves, and sampled-to-selection bridges.

The remaining general Section 6 construction is:

1. Construct and normalize the actual regularity partition and balanced
   core moves, and connect the proved integer cluster adjustment to that
   geometric partition.
2. Connect the constructed coupled absorber integers and positive even
   palette targets to the full hierarchy and actual bi-setup. The exact
   identities `k₁=2r₃`, `k₂=2r◇`, structural divisibilities, and source
   palette budgets already proved in `AbsorberParameters.lean` should be
   reused.
3. Construct the final forward-copy boundary after insertions and
   equalization, with both its normalized-weight and cardinality bounds.
4. Assemble allowed colors, both correction orientations, samples, reserves,
   and exact copy accounting into one uniform construction of both colored
   families from the original robust-core hypotheses.
5. Construct the special path systems and robust absorber, apply the proved
   reserved-remainder packing and orientation, and reconstruct the
   factorization of the actual entire residual multigraph.

A graph containing a bipartite robust core may still have same-side and
exceptional copies. The generic reserved-remainder stage therefore cannot
finish with König until the whole remainder has been proved bipartite or
otherwise factored. The new two-apex proof establishes precisely that
whole-remainder property in its own restricted setting. The new ordinary
bounded-exterior proof constructs it using its cut choice. Neither supplies
it for every Section 6 input.

## Independent remaining routes

### Proposition 2.24: criticality to the partition input

The [critical-partition development](critical-partition-consequences.md)
derives the deterministic conclusions from the actual normalized
average-degree estimate. Its thresholds precede the graph; the low-degree
set is the source's actual set; and its degree and shore bounds refer to
the actual induced survivor and original order.

The missing input is the Cao–Chen criticality-to-average-degree theorem,
followed by the uniform threshold composition. The existing deterministic
partition construction does not prove that estimate. A proof of the
original criticality result is required before counting Proposition 2.24.

### Dense triangle decomposition and coloring extension

The dense development includes the fractional triangle decomposition,
finite absorbers, signed flows, integer balance repair, and full dense
link packing. The full triangle decomposition of Lemma 5.13 still needs
the approximate integral packing and iterative absorption chain. The
weighted hypergraph matching/nibble input of Lemma 5.8 remains substantive
new mathematics. The checked encoding equivalence does not itself
construct the triangle decomposition needed for Lemma 5.14 or the dense
coloring conclusion of Theorem 5.1.

## Historical checkpoints and source preservation

The direct [Lemma 4.15 proof](four-odd-decomposition.md) raised the inventory
to **45 of 69**. It uses the sufficient error-ratio bound `1/1000` and
constructs the complete joining-edge decomposition from the original graph
hypotheses. Theorem 2.23 had previously raised the count to 44; the
subsequent 109 supporting proofs in 13 modules retained that earlier count.
The full Lemma 4.14 added the forty-sixth numbered assertion, and the full
Lemma 4.2 now adds the forty-seventh.

The combined tree also preserves the published circuit checkpoint
`54db7b8` and its alternate proof of Lemma 4.13. The
[recovery manifest](source-recovery.json) records exact source identities
and namespace mappings. Its [circuit and forest components](four-odd-circuits.md)
remain available. The general compatible-circuit theorem is still
unproved; the direct proof of Lemma 4.15 and the new one-apex proof of
Lemma 4.14 do not depend on that general theorem. Two proofs of Lemma 4.13
still count as one numbered assertion.

## Acceptance conditions for another complete assertion

Choose a full numbered source statement and retain its original graph
hypotheses, quantifier order, and conclusion. Every additional structure
needed by a specialized proof must be constructed from those hypotheses.
A wrapper that takes the desired residual coloring, decomposition,
spanning setup, or absorber as an unproved premise is a supporting result,
not a complete assertion.

The completed conclusion must concern the actual graph and original edge
copies. Prescribed colors must be restored when the source requires them.
All graph-independent tolerances and thresholds must be selected before
the graph. The proof must be imported, source-mapped, semantically reviewed,
and included in the strict build and complete stock-axiom audit before
another checkpoint is reported as verified. The current proof inventory
is **47/69**; the new continuation has passed its targeted build and
semantic review. The repository-wide status, full axiom inventory, and
exact source/input hashes are recorded in
[verification/results.json](../verification/results.json). The main theorem
remains unverified.
